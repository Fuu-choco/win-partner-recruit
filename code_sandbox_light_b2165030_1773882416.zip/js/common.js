/* ============================================================
   common.js  —  全ページ共通パーツの自動挿入
   ヘッダー / Download・Contact / SNS / フッター
   ============================================================ */

(function () {

  /* ---- ヘッダー HTML ---- */
  const HEADER_HTML = `
  <header id="site-header">
    <a href="index.html" class="logo">WIN PARTNER</a>
    <div class="header-right">
      <a href="download.html" class="btn-outline light">Download</a>
      <a href="contact.html"  class="btn-outline">Contact</a>
    </div>
  </header>`;

  /* ---- Download / Contact HTML ---- */
  const DL_CONTACT_HTML = `
  <div id="dl-contact" class="section-border">
    <div class="dl-contact-grid fade-in">
      <div class="dl-contact-item">
        <p class="dl-contact-en">Download</p>
        <p class="dl-contact-ja">資料ダウンロード</p>
        <p class="dl-contact-desc">
          弊社の採用資料などをまとめた資料を<br>
          今すぐPDFでダウンロードできます。
        </p>
        <a href="download.html" class="dl-contact-btn">資料をダウンロードする →</a>
      </div>
      <div class="dl-contact-item">
        <p class="dl-contact-en">Contact</p>
        <p class="dl-contact-ja">お問い合わせ</p>
        <p class="dl-contact-desc">
          採用に関するご質問やエントリーは<br>
          こちらからお気軽にご連絡ください。
        </p>
        <a href="contact.html" class="dl-contact-btn">お問い合わせする →</a>
      </div>
    </div>
  </div>`;

  /* ---- SNS HTML ---- */
  const SNS_HTML = `
  <div id="sns">
    <div class="sns-inner">
      <div class="sns-list fade-in">
        <div class="sns-item">
          <div class="sns-icon yt">
            <svg viewBox="0 0 24 24"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1C24 15.9 24 12 24 12s0-3.9-.5-5.8zM9.75 15.5V8.5l6.25 3.5-6.25 3.5z"/></svg>
          </div>
          YouTubeアカウント
        </div>
        <div class="sns-item">
          <div class="sns-icon x">
            <svg viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
          </div>
          Xアカウント
        </div>
        <div class="sns-item">
          <div class="sns-icon line">
            <svg viewBox="0 0 24 24"><path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.627-.63h2.386c.349 0 .63.285.63.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.627-.63.349 0 .631.285.631.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.281.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/></svg>
          </div>
          LINEアカウント
        </div>
      </div>
    </div>
  </div>`;

  /* ---- フッター HTML ---- */
  const FOOTER_HTML = `
  <footer>
    <div class="footer-inner">
      <div>
        <p class="footer-logo-en">WIN PARTNER</p>
        <p class="footer-logo-ja">株式会社ウィンパートナー</p>
        <p class="footer-address">
          〒000-0000 大阪市◯◯区◯◯<br>
          TEL.00-0000-0000<br><br>
          〒000-0000 東京都◯◯区◯◯<br>
          TEL.00-0000-0000
        </p>
      </div>
      <nav class="footer-nav-grid">
        <div class="footer-nav-col">
          <h5>Blog</h5>
        </div>
        <div class="footer-nav-col">
          <h5>Service</h5>
          <ul>
            <li><a href="#">コンサルティング</a></li>
            <li><a href="#">ブランドデザイン</a></li>
            <li><a href="#">WEB制作</a></li>
          </ul>
        </div>
        <div class="footer-nav-col">
          <h5>Company</h5>
          <ul>
            <li><a href="#">会社概要</a></li>
            <li><a href="#">代表メッセージ</a></li>
            <li><a href="#">アクセス</a></li>
          </ul>
        </div>
        <div class="footer-nav-col">
          <h5>Recruit</h5>
          <ul>
            <li><a href="jobs.html">募集要項</a></li>
            <li><a href="benefits.html">福利厚生</a></li>
            <li><a href="positions.html">募集職種</a></li>
            <li><a href="flow.html">採用フロー</a></li>
            <li><a href="contact.html">エントリー</a></li>
          </ul>
        </div>
        <div class="footer-nav-col">
          <h5>Download</h5>
          <ul>
            <li><a href="download.html">会社資料</a></li>
            <li><a href="download.html">採用資料</a></li>
          </ul>
        </div>
      </nav>
    </div>
    <div class="footer-bottom">
      <p class="footer-copy">©WIN PARTNER INC.</p>
      <a href="#" class="footer-privacy">プライバシーポリシー</a>
    </div>
  </footer>`;


  /* ============================================================
     DOM への挿入
  ============================================================ */
  document.addEventListener('DOMContentLoaded', function () {

    /* 1. ヘッダー：body の先頭に挿入 */
    document.body.insertAdjacentHTML('afterbegin', HEADER_HTML);

    /* 2. Download/Contact + SNS + フッター：body 末尾に挿入
          ただし #common-footer-anchor がある場合はその直前に挿入 */
    const anchor = document.getElementById('common-footer-anchor');
    if (anchor) {
      anchor.insertAdjacentHTML('beforebegin', DL_CONTACT_HTML + SNS_HTML + FOOTER_HTML);
      anchor.remove();
    } else {
      document.body.insertAdjacentHTML('beforeend', DL_CONTACT_HTML + SNS_HTML + FOOTER_HTML);
    }

    /* 3. 現在ページのナビリンクをアクティブ表示 */
    const currentPath = location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.footer-nav-col a').forEach(a => {
      if (a.getAttribute('href') === currentPath) {
        a.style.color = '#ffffff';
        a.style.fontWeight = '500';
      }
    });

    /* 4. Intersection Observer（fade-in） */
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) e.target.classList.add('visible');
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in').forEach(el => io.observe(el));

    /* 5. スムーススクロール */
    document.querySelectorAll('a[href^="#"]').forEach(a => {
      a.addEventListener('click', function (e) {
        const id = this.getAttribute('href');
        if (id === '#') return;
        const target = document.querySelector(id);
        if (target) {
          e.preventDefault();
          const top = target.getBoundingClientRect().top + window.pageYOffset - 64;
          window.scrollTo({ top, behavior: 'smooth' });
        }
      });
    });

  });

})();
